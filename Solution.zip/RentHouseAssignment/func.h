#pragma once//��֤ͷ�ļ�ֻ������һ��
char* replaceCommaWithSpace(char* str);
void processString(char* input);
int compareHousePriceDown(const void* a, const void* b);
int compareHouseCode(const void* a, const void* b);
int countNonZeroElements(int array[], int size);
int compareHousePriceUp(const void* a, const void* b);